using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web_FoodBasket.Pages
{
    public class CreateAccountModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
